Authors	Joukje Kloosterman & Job Maathuis
Date	03-12-2020
Version	1

Pypovray Simulating - Part One
In this we simulated two animation using Povray.
In the first assignment we made an sphere making a seesaw wave.
In the second one we rotated a camera around objects. 


Installation
https://nbviewer.jupyter.org/urls/bitbucket.org/mkempenaar/pypovray/raw/master/manual/pypovray_basic.ipynb
An importable legend is also needed (2nd assignment)

Usage
python3 assignment3.py
python3 assignment4.py 


Email: 	j.kloosterman@st.hanze.nl
	or
	j.maathuis@st.hanze.nl

Thank you teachers for making this project possible.


